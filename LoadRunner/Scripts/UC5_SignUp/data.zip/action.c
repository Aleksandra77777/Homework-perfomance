Action()
{

	lr_start_transaction("welcome");

	lr_start_transaction("welcome_page");

	return 0;
}