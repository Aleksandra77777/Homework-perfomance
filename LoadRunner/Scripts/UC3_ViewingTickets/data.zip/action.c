Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("sec-ch-ua", 
		"\"Chromium\";v=\"124\", \"Google Chrome\";v=\"124\", \"Not-A.Brand\";v=\"99\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_custom_request("WebTours", 
		"URL=http://localhost:1080/WebTours", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Dest", 
		"frame");

	web_concurrent_start(NULL);

	web_custom_request("header.html", 
		"URL=http://localhost:1080/WebTours/header.html", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/WebTours/", 
		"Snapshot=t2.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Dest", 
		"frame");

	web_custom_request("welcome.pl", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=true", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/WebTours/", 
		"Snapshot=t4.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_end(NULL);

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Dest", 
		"image");

	web_concurrent_start(NULL);

	web_custom_request("hp_logo.png", 
		"URL=http://localhost:1080/WebTours/images/hp_logo.png", 
		"Method=GET", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=http://localhost:1080/WebTours/header.html", 
		"Snapshot=t3.inf", 
		LAST);

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Dest", 
		"image");

	web_custom_request("webtours.png", 
		"URL=http://localhost:1080/WebTours/images/webtours.png", 
		"Method=GET", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=http://localhost:1080/WebTours/header.html", 
		"Snapshot=t5.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Dest", 
		"frame");

	web_concurrent_start(NULL);

	web_custom_request("home.html", 
		"URL=http://localhost:1080/WebTours/home.html", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/welcome.pl?signOff=true", 
		"Snapshot=t6.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Dest", 
		"frame");

	web_custom_request("nav.pl", 
		"URL=http://localhost:1080/cgi-bin/nav.pl?in=home", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/welcome.pl?signOff=true", 
		"Snapshot=t7.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_end(NULL);

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("X-Client-Data", 
		"CIq2yQEIpLbJAQipncoBCPqEywEIkqHLAQia/swBCIWgzQEI3e7NAQji+s0BCNKOzgEIzZDOARj0yc0B");

	lr_think_time(33);

	web_custom_request("command", 
		"URL=https://clients4.google.com/chrome-sync/command/?client=Google+Chrome&client_id=zYwD%2FaC%2FZPvFUDteQtvEDg%3D%3D", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/vnd.google.octet-stream-compressible", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTTP", 
		"EncType=application/octet-stream", 
		"BodyBinary=\n\\x11shop@nikkmole.com\\x10c\\x18\\x02*R\\x12\\x02\\x10\\x00\\x18\\x012\\x04\\x08\\xCE\\x87G2\\x04\\x08\\xDE\\xD8\\x122:\\x08\\x81\\xF5\\x02\\x124 \\x00\\x88\\x01\\xBF\\xC0\\x9C\\xA1\\xB4\\xAC\\xD6\\xB4\\x01\\xC2\\x01$0182390c-fec6-51b0-82b7-bb284b448a9b@\\x00H\\x0E:%z0000016c-051f-dffc-0000-00005acca503R\\x18\n\\x02\\x08\\x05\n\\x02\\x08\t\n\\x02\\x08\n\n\\x04\\x18\\x9A\\xB7\t\\x10\\x01\\x18\\x00 \\x00Z\\x7F\n}\\x12{Chrome WIN 124.0.6367.78 "
		"(a087f2dd364ddd58b9c016ef1bf563d2bc138711-refs/branch-heads/6367@{#954}) channel(stable),gzip(gfe)b'AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgwj\\x02\\x10\\x00", 
		LAST);

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Dest", 
		"image");

	web_add_header("sec-ch-ua", 
		"\"Chromium\";v=\"124\", \"Google Chrome\";v=\"124\", \"Not-A.Brand\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_custom_request("mer_login.gif", 
		"URL=http://localhost:1080/WebTours/images/mer_login.gif", 
		"Method=GET", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home", 
		"Snapshot=t9.inf", 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("X-Client-Data", 
		"CIq2yQEIpLbJAQipncoBCPqEywEIkqHLAQia/swBCIWgzQEI3e7NAQji+s0BCNKOzgEIzZDOARj0yc0B");

	web_custom_request("command_2", 
		"URL=https://clients4.google.com/chrome-sync/command/?client=Google+Chrome&client_id=zYwD%2FaC%2FZPvFUDteQtvEDg%3D%3D", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/vnd.google.octet-stream-compressible", 
		"Referer=", 
		"Snapshot=t10.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTTP", 
		"EncType=application/octet-stream", 
		"BodyBinary=\n\\x11shop@nikkmole.com\\x10c\\x18\\x02*\\x8C\\x05\\x12\\x02\\x10\\x01\\x18\\x012\\x99\\x01\\x08\\xCE\\x87G\\x12\\x82\\x01 \\x00\\x92\\x01}\n4\n\\x0Echrome_sync_aw\\x12\\x0551!aw\\x1A\\x12\t\\xD3\\x01l\\xBAZ\\x18\\x06\\x00\\x11\\xD3\\x01l\\xBAZ\\x18\\x06\\x00)\\x04\\xAAl\\xBAZ\\x18\\x06\\x00\nE\n\\x16annotation_chrome_sync\\x12\\x0551!bd\\x1A\\x12\t\\x80\\xD8i\\xB5Z\\x18\\x06\\x00\\x11\\x80\\xD8i\\xB5Z\\x18\\x06\\x00)|"
		"\\xA6l\\xBAZ\\x18\\x06\\x000\\x80\\xB1\\xA7\\xAB\\xAB\\x8B\\x86\\x03*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002+\\x08\\xDE\\xD8\\x12\\x12\\x15 \\x00x\\xA5\\xE1\\x9D\\x94\\xF9\\xFF\\xFF\\xFF\\xFF\\x01\\x80\\x01\\xDC\\xDB\\x8B\\x9B\\xF71*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\xCC\\x01\\x08\\x9A\\xB7\t\\x12\\xB5\\x01 \\x00\\x92\\x01\\xAF\\x01\nf\n\\x0Echrome_sync_di\\x12\\x0551!di\\x1A\\x12\t\\x14c\\x0B]Z\\x18\\x06\\x00\\x11\\x14c\\x0B]Z\\x18\\x06\\x00\"0\t\\x11\\x0E"
		"\t]Z\\x18\\x06\\x00\\x10\\x01\\x19\\xE8\\xE4\\xBB\\xC2I\\x8C\\x90\\x81 \\x01*\\x1851!di:434067016277066740)\\xA4,\\x0C]Z\\x18\\x06\\x00\nE\n\\x16annotation_chrome_sync\\x12\\x0551!bd\\x1A\\x12\t\\x80\"nXZ\\x18\\x06\\x00\\x11\\x80\"nXZ\\x18\\x06\\x00)\\x9A\\x06\\x0C]Z\\x18\\x06\\x000\\x80\\xC5\\xB8\\xC3\\xA5\\x8B\\x86\\x03*\\x0E\\x10\\x00\\x18\\x01 \\x02(\\x000\\x008\\x00@\\x002\\x99\\x01\\x08\\xFC\\xDE$\\x12\\x82\\x01 \\x00\\x92\\x01}\n4\n\\x0Echrome_sync_st\\x12\\x0551!st\\x1A\\x12\t\\x14c\\x0B]"
		"Z\\x18\\x06\\x00\\x11\\x14c\\x0B]Z\\x18\\x06\\x00)\\xD6,\\x0C]Z\\x18\\x06\\x00\nE\n\\x16annotation_chrome_sync\\x12\\x0551!bd\\x1A\\x12\t\\x80\"nXZ\\x18\\x06\\x00\\x11\\x80\"nXZ\\x18\\x06\\x00)\\x9A\\x06\\x0C]Z\\x18\\x06\\x000\\x80\\xC5\\xB8\\xC3\\xA5\\x8B\\x86\\x03*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002J\\x08\\x81\\xF5\\x02\\x124 \\x00\\x88\\x01\\xBF\\xC0\\x9C\\xA1\\xB4\\xAC\\xD6\\xB4\\x01\\xC2\\x01$0182390c-fec6-51b0-82b7-bb284b448a9b*\\x0E\\x10\\x00\\x18\\x01 \\x00"
		"(\\x000\\x008\\x00@\\x00@\\x00H\\x0CP\\x00:%z0000016c-051f-dffc-0000-00005acca503R\\x1A\n\\x0C\\x12\n8\\x00@\\x01R\\x02\\x10\\x00`\\x0E\n\\x04\\x18\\x9A\\xB7\t\\x10\\x01\\x18\\x00 \\x00Z\\x81\\x01\n\\x7F\\x12}Chrome WIN 124.0.6367.158 (953cfe4b1b3504ce4c1c2a5054dfdabf2747237a-refs/branch-heads/6367@{#1100}) channel(stable),gzip(gfe)b'AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgwj\\x02\\x10\\x00", 
		LAST);

	web_custom_request("command_3", 
		"URL=https://clients4.google.com/chrome-sync/command/?client=Google+Chrome&client_id=zYwD%2FaC%2FZPvFUDteQtvEDg%3D%3D", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/vnd.google.octet-stream-compressible", 
		"Referer=", 
		"Snapshot=t11.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTTP", 
		"EncType=application/octet-stream", 
		"BodyBinary=\n\\x11shop@nikkmole.com\\x10c\\x18\\x01\"\\x8D\n\n\\xC3\\x07\nfZ:ADqtAZwIwfVypqqSWZhJm/a73r4hbWae9AGoezvhCT96GHcd9BeyPa8nffklt0H8vQam2+eNhGguew+67sp4Zm9QXYznRALJIQ== \\x91\\x9C\\xA4\\xE8\\xA5\\x8B\\x86\\x03(\\xCB\\xD6\\x8B\\x9B\\xF710\\xBA\\xFD\\xAC\\xD6\\xF31:&HP Pavilion x360 Convertible 14-dh0xxx\\x90\\x01\\x00\\xAA\\x01\\xF6\\x05\\xD2\\xB9K\\xF1\\x05\n\\x18zYwD/aC/ZPvFUDteQtvEDg==\\x12&HP Pavilion x360 Convertible 14-dh0xxx\\x18\\x01\"sChrome WIN 124.0.6367.158 "
		"(953cfe4b1b3504ce4c1c2a5054dfdabf2747237a-refs/branch-heads/6367@{#1100}) channel(stable)*\\x0E124.0.6367.158:$f9dc4208-e059-4590-9e7d-9e6a29d0a267@\\xCB\\xD6\\x8B\\x9B\\xF71J\\x02\\x08\\x01R\\xFA\\x01\n\\x00\\x12\\x00\\x1A\\x00 \\x04 \\x08B\\x98\\x01dD8u1RuLvsg:APA91bElE3yE5MkfwD9tXMz4SKrV5BNAQIxilj5nBv1L0SbZPuafZuA6FBkMMQEXICm5nhvlMHiUqcU7cBpyhN-g6Eunk0Pp5XPJ8A76crx7RkuwhEfVtaXukXg458sTSQudDgZXyeyyJA\\x04\\xA4M\\xA3\\xF8\\x01|\\xE2\\xC2\\xE0i\\x0C\\x0C\\xF3D\\xDE\\xCDacYe\\x9E\\xC02\\xB7\""
		"\\xA9\\xB8\\x1D\\x1E\\xAC\\xC3~\\x86\\xB8\\x02\\x94\\x06\\x8CJ\\xEE\\xAC\\xED\\xEE\\xC3\\x95\\xDEu\\x18CSO*\\x13\\x8A\\xA4\\xB0\\x16\\x05b\\x16\\x93\\xCFe\\x8FR\\x10%\\x8B\\xD8\\x14W\\x0C`SM\t4}.\\x82\\xAATZ&HP Pavilion x360 Convertible 14-dh0xxxb\\x02HPh\\xA0\\x0Br\\xAF\\x01\n\\x98\\x01c_9HK1DgOKQ:APA91bGS3nn9TuxZSuwgL_6KH__es2Y4MM3IGoDbWDYYj40Z0wvCnsgcCJYy84BodtCUF5dSfddrdoHJMtO77CpnneMycFGgMSkW_grHQmUC9wa0iQAb-d_eubU1s-mZrhAT1ErVPa3P\\x10\\xCE\\x87G\\x10\\xDE\\xD8\\x12\\x10\\x9A\\xB7\t"
		"\\x10\\xFC\\xDE$\\x10\\x81\\xF5\\x02\\x8A\\x01\\x10\n\\x0E124.0.6367.158\\x98\\x01\\x01\\xA0\\x01\\x01\\xBA\\x01\\x1CXboBQz3y83t0i5T5YFJrj9y+ox8=\\x12\\x18zYwD/aC/ZPvFUDteQtvEDg==\"(\\x08\\xCE\\x87G\\x08\\xDE\\xD8\\x12\\x08\\x9A\\xB7\t\\x08\\xEE\\xF7!\\x08\\xFC\\xDE$\\x08\\xB4\\xD2$\\x08\\xA2\\xBE,\\x08\\x81\\xF5\\x02\\x18\\x00 \\x010\\x01@\\x012\\x80\\x02U@&iHS)\"1)sQ]gB/:w|sU;Y}dP)iLyHOOgZ}8&HMusqm7='OJ`>?!v/'t\\\\sP-O7;38OsOrkq_YWb>C@x~TIz.L:k}U-KB6l1<OyR7K2d\")[\\\\ZJR_/>1xOg^W_B@D Ue#QS3BW+"
		"MbBZDB`)P~e5'&\"\\\\q^@IX\"}t i*n{\\\\}7\\\\*k_XyNT}n!Gp/[Y0l~U+6\"'E;'\"kBDT>M9]7}S!DFweS_%*O_PESl\"+=ikdumD3GsBu+mdR#m:T9'0cJY:JO4L;-,:%z0000016c-051f-dffc-0000-00005acca503R\\x06\\x10\\x01\\x18\\x00 \\x00Z\\x81\\x01\n\\x7F\\x12}Chrome WIN 124.0.6367.158 (953cfe4b1b3504ce4c1c2a5054dfdabf2747237a-refs/branch-heads/6367@{#1100}) channel(stable),gzip(gfe)b'AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgwj\\x02\\x10\\x00", 
		LAST);

	web_custom_request("command_4", 
		"URL=https://clients4.google.com/chrome-sync/command/?client=Google+Chrome&client_id=zYwD%2FaC%2FZPvFUDteQtvEDg%3D%3D", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/vnd.google.octet-stream-compressible", 
		"Referer=", 
		"Snapshot=t12.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTTP", 
		"EncType=application/octet-stream", 
		"BodyBinary=\n\\x11shop@nikkmole.com\\x10c\\x18\\x02*\\xD9\\x04\\x12\\x02\\x10\\x01\\x18\\x012\\x99\\x01\\x08\\xCE\\x87G\\x12\\x82\\x01 \\x00\\x92\\x01}\n4\n\\x0Echrome_sync_aw\\x12\\x0551!aw\\x1A\\x12\t[\\x1Bt\\xBAZ\\x18\\x06\\x00\\x11[\\x1Bt\\xBAZ\\x18\\x06\\x00)f\\xBBt\\xBAZ\\x18\\x06\\x00\nE\n\\x16annotation_chrome_sync\\x12\\x0551!bd\\x1A\\x12\t\\x80\\xD8i\\xB5Z\\x18\\x06\\x00\\x11\\x80\\xD8i\\xB5Z\\x18\\x06\\x00)"
		"\\xE6\\x98t\\xBAZ\\x18\\x06\\x000\\x80\\xB1\\xA7\\xAB\\xAB\\x8B\\x86\\x03*\\x0E\\x10\\x00\\x18\\x00 \\x00(\\x010\\x008\\x00@\\x002+\\x08\\xDE\\xD8\\x12\\x12\\x15 \\x00x\\xA5\\xE1\\x9D\\x94\\xF9\\xFF\\xFF\\xFF\\xFF\\x01\\x80\\x01\\xDC\\xDB\\x8B\\x9B\\xF71*\\x0E\\x10\\x00\\x18\\x00 \\x00(\\x000\\x008\\x00@\\x002\\x99\\x01\\x08\\x9A\\xB7\t\\x12\\x82\\x01 \\x00\\x92\\x01}\n4\n\\x0Echrome_sync_di\\x12\\x0551!di\\x1A\\x12\t[\\x1Bt\\xBAZ\\x18\\x06\\x00\\x11[\\x1Bt\\xBAZ\\x18\\x06\\x00)~"
		"\\xBBt\\xBAZ\\x18\\x06\\x00\nE\n\\x16annotation_chrome_sync\\x12\\x0551!bd\\x1A\\x12\t\\x80\\xD8i\\xB5Z\\x18\\x06\\x00\\x11\\x80\\xD8i\\xB5Z\\x18\\x06\\x00)\\xE6\\x98t\\xBAZ\\x18\\x06\\x000\\x80\\xB1\\xA7\\xAB\\xAB\\x8B\\x86\\x03*\\x0E\\x10\\x00\\x18\\x00 \\x01(\\x000\\x008\\x00@\\x002\\x99\\x01\\x08\\xFC\\xDE$\\x12\\x82\\x01 \\x00\\x92\\x01}\n4\n\\x0Echrome_sync_st\\x12\\x0551!st\\x1A\\x12\t[\\x1Bt\\xBAZ\\x18\\x06\\x00\\x11[\\x1Bt\\xBAZ\\x18\\x06\\x00)\\x8A\\xBBt\\xBAZ\\x18\\x06\\x00\nE\n"
		"\\x16annotation_chrome_sync\\x12\\x0551!bd\\x1A\\x12\t\\x80\\xD8i\\xB5Z\\x18\\x06\\x00\\x11\\x80\\xD8i\\xB5Z\\x18\\x06\\x00)\\xE6\\x98t\\xBAZ\\x18\\x06\\x000\\x80\\xB1\\xA7\\xAB\\xAB\\x8B\\x86\\x03*\\x0E\\x10\\x00\\x18\\x00 \\x00(\\x000\\x008\\x00@\\x002J\\x08\\x81\\xF5\\x02\\x124 \\x00\\x88\\x01\\xBF\\xC0\\x9C\\xA1\\xB4\\xAC\\xD6\\xB4\\x01\\xC2\\x01$0182390c-fec6-51b0-82b7-bb284b448a9b*\\x0E\\x10\\x00\\x18\\x00 \\x00(\\x000\\x008\\x00@\\x00@\\x00H\\x0CP\\x00"
		":%z0000016c-051f-dffc-0000-00005acca503R\\x1A\n\\x0C\\x12\n8\\x00@\\x00R\\x02\\x10\\x01`\\x0C\n\\x04\\x18\\x9A\\xB7\t\\x10\\x01\\x18\\x00 \\x00Z\\x81\\x01\n\\x7F\\x12}Chrome WIN 124.0.6367.158 (953cfe4b1b3504ce4c1c2a5054dfdabf2747237a-refs/branch-heads/6367@{#1100}) channel(stable),gzip(gfe)b'AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgwj\\x02\\x10\\x00", 
		LAST);

	lr_start_transaction("login");

	web_revert_auto_header("X-Client-Data");

	web_add_auto_header("sec-ch-ua", 
		"\"Chromium\";v=\"124\", \"Google Chrome\";v=\"124\", \"Not-A.Brand\";v=\"99\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("Origin", 
		"http://localhost:1080");

	web_add_auto_header("Sec-Fetch-Dest", 
		"frame");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	lr_think_time(142);

	web_custom_request("login.pl", 
		"URL=http://localhost:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home", 
		"Snapshot=t13.inf", 
		"Mode=HTTP", 
		"Body=userSession=138973.493722155HVtittQpAiDDDDDDtciQApzQtf&username=jojo&password=bean&login.x=58&login.y=11&JSFormSubmit=off", 
		LAST);

	web_concurrent_start(NULL);

	web_custom_request("nav.pl_2", 
		"URL=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/login.pl", 
		"Snapshot=t14.inf", 
		"Mode=HTTP", 
		LAST);

	web_custom_request("login.pl_2", 
		"URL=http://localhost:1080/cgi-bin/login.pl?intro=true", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/login.pl", 
		"Snapshot=t15.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_end(NULL);

	web_concurrent_start(NULL);

	web_custom_request("flights.gif", 
		"URL=http://localhost:1080/WebTours/images/flights.gif", 
		"Method=GET", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t16.inf", 
		LAST);

	web_custom_request("itinerary.gif", 
		"URL=http://localhost:1080/WebTours/images/itinerary.gif", 
		"Method=GET", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t17.inf", 
		LAST);

	web_custom_request("in_home.gif", 
		"URL=http://localhost:1080/WebTours/images/in_home.gif", 
		"Method=GET", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t18.inf", 
		LAST);

	web_custom_request("signoff.gif", 
		"URL=http://localhost:1080/WebTours/images/signoff.gif", 
		"Method=GET", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t19.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("login",LR_AUTO);

	lr_think_time(141);

	lr_start_transaction("itinerary");

	web_custom_request("Itinerary Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=itinerary", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t20.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_start(NULL);

	web_custom_request("nav.pl_3", 
		"URL=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=itinerary", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/welcome.pl?page=itinerary", 
		"Snapshot=t21.inf", 
		"Mode=HTTP", 
		LAST);

	web_custom_request("itinerary.pl", 
		"URL=http://localhost:1080/cgi-bin/itinerary.pl", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/welcome.pl?page=itinerary", 
		"Snapshot=t22.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_end(NULL);

	web_concurrent_start(NULL);

	web_custom_request("in_itinerary.gif", 
		"URL=http://localhost:1080/WebTours/images/in_itinerary.gif", 
		"Method=GET", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=itinerary", 
		"Snapshot=t23.inf", 
		LAST);

	web_custom_request("home.gif", 
		"URL=http://localhost:1080/WebTours/images/home.gif", 
		"Method=GET", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=itinerary", 
		"Snapshot=t24.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_concurrent_start(NULL);

	web_custom_request("cancelallreservations.gif", 
		"URL=http://localhost:1080/WebTours/images/cancelallreservations.gif", 
		"Method=GET", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://localhost:1080/cgi-bin/itinerary.pl", 
		"Snapshot=t25.inf", 
		LAST);

	web_custom_request("cancelreservation.gif", 
		"URL=http://localhost:1080/WebTours/images/cancelreservation.gif", 
		"Method=GET", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://localhost:1080/cgi-bin/itinerary.pl", 
		"Snapshot=t26.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("itinerary",LR_AUTO);

	lr_think_time(73);

	lr_start_transaction("sign off");

	web_custom_request("SignOff Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=1", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=itinerary", 
		"Snapshot=t27.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_start(NULL);

	web_custom_request("home.html_2", 
		"URL=http://localhost:1080/WebTours/home.html", 
		"Method=GET", 
		"Resource=0", 
		"Referer=http://localhost:1080/cgi-bin/welcome.pl?signOff=1", 
		"Snapshot=t28.inf", 
		"Mode=HTTP", 
		LAST);

	web_custom_request("nav.pl_4", 
		"URL=http://localhost:1080/cgi-bin/nav.pl?in=home", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/welcome.pl?signOff=1", 
		"Snapshot=t29.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("sign off",LR_AUTO);

	return 0;
}